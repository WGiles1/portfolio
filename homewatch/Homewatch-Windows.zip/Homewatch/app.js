(() => {
  const key = 'homewatch.inventory.v1';
  const $ = id => document.getElementById(id);
  let inventory, editing = null, storageReady = true;
  try {
    const raw = localStorage.getItem(key);
    const data = raw ? JSON.parse(raw) : {};
    if (raw && (!data || !Array.isArray(data.devices) || !Array.isArray(data.history))) throw new Error('Invalid saved data');
    inventory = new Inventory(data);
  } catch (error) {
    storageReady = false; inventory = new Inventory();
    alert('Saved inventory could not be loaded. Editing is disabled to protect your data. Check browser storage settings.');
  }
  function save() {
    try { localStorage.setItem(key, JSON.stringify({ devices: inventory.devices, history: inventory.history })); return true; }
    catch (error) { alert('Could not save to browser storage. Your changes may be lost when you close this page.'); return false; }
  }
  function text(tag, value, className) { const el = document.createElement(tag); el.textContent = value; if (className) el.className = className; return el; }
  function render() {
    $('total').textContent = inventory.devices.length;
    $('known').textContent = inventory.devices.filter(d => d.status === 'known').length;
    $('unfamiliar').textContent = inventory.devices.filter(d => d.status === 'unfamiliar').length;
    $('device-count').textContent = inventory.devices.length;
    const list = $('device-list'); list.replaceChildren();
    const query = $('search').value.trim().toLowerCase();
    const devices = inventory.devices.filter(d => [d.name, d.type, d.address, d.notes, d.status].some(v => String(v || '').toLowerCase().includes(query)));
    $('empty').hidden = devices.length > 0;
    $('empty').querySelector('strong').textContent = query ? 'No matching devices' : 'No devices here yet';
    $('empty').querySelector('p').textContent = query ? 'Try a different search.' : 'Add a device to start building your inventory.';
    $('empty-add').hidden = !!query;
    devices.forEach(d => {
      const row = document.createElement('tr');
      const identity = document.createElement('td'); const wrap = document.createElement('div'); wrap.className = 'device-name';
      wrap.append(text('span', '▣', 'device-icon')); const title = document.createElement('div'); title.append(text('strong', d.name), text('small', d.type || 'Device')); wrap.append(title); identity.append(wrap);
      const details = document.createElement('td'); details.append(text('strong', d.address || '—', 'address'), text('small', [d.mac, d.lastSeen ? `Last seen ${new Date(d.lastSeen).toLocaleString()}` : '', d.notes].filter(Boolean).join(' · ') || 'No notes'));
      const status = document.createElement('td'); status.append(text('span', d.status === 'known' ? '●  Known' : '●  Unfamiliar', `badge ${d.status === 'known' ? 'known' : 'unknown'}`));
      const actions = document.createElement('td'); actions.className = 'actions';
      const edit = text('button', 'Edit', 'row-button'); edit.type = 'button'; edit.setAttribute('aria-label', `Edit ${d.name}`); edit.addEventListener('click', () => openForm(d));
      const del = text('button', 'Delete', 'row-button delete'); del.type = 'button'; del.setAttribute('aria-label', `Delete ${d.name}`); del.addEventListener('click', () => { if (storageReady && confirm(`Delete ${d.name} from your inventory?`)) { inventory.remove(d.id); save(); render(); } });
      actions.append(edit, del); row.append(identity, details, status, actions); list.append(row);
    });
    const history = $('history'); history.replaceChildren();
    if (!inventory.history.length) { const empty = text('div', 'No changes yet. Your manual updates will appear here.', 'history-empty'); history.append(empty); }
    inventory.history.slice(0, 30).forEach(event => { const item = document.createElement('div'); item.className = 'history-item'; const detail = document.createElement('div'); detail.append(text('strong', event.text), text('small', new Date(event.time).toLocaleString())); item.append(text('span', '·', 'timeline-dot'), detail); history.append(item); });
  }
  function openForm(device) {
    if (!storageReady) return;
    editing = device ? device.id : null;
    const form = $('device-form'); form.reset(); $('form-error').textContent = '';
    $('dialog-title').textContent = device ? 'Edit device' : 'Add device';
    if (device) ['name', 'type', 'address', 'status', 'notes'].forEach(key => { form.elements[key].value = device[key] || ''; });
    $('device-dialog').showModal(); form.elements.name.focus();
  }
  $('add-button').addEventListener('click', () => openForm()); $('empty-add').addEventListener('click', () => openForm());
  $('close-dialog').addEventListener('click', () => $('device-dialog').close()); $('cancel').addEventListener('click', () => $('device-dialog').close());
  $('search').addEventListener('input', render);
  $('device-form').addEventListener('submit', event => {
    event.preventDefault(); const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    try { if (editing) inventory.update(editing, data); else inventory.add(data); save(); $('device-dialog').close(); render(); }
    catch (error) { $('form-error').textContent = error.message; }
  });
  $('backup-export').addEventListener('click', () => {
    if (!storageReady) { $('backup-message').textContent = 'Saved data could not be read; export is disabled.'; return; }
    const blob = new Blob([Backup.exportJSON(inventory)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = 'homewatch-backup.json'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  $('backup-import').addEventListener('click', () => {
    if (!storageReady) { $('backup-message').textContent = 'Saved data could not be read; import is disabled to protect it.'; return; }
    $('backup-file').click();
  });
  $('backup-file').addEventListener('change', async event => {
    const file = event.currentTarget.files[0]; event.currentTarget.value = '';
    if (!file) return;
    try {
      if (file.size > 10 * 1024 * 1024) throw new Error('Backup exceeds the 10 MB limit.');
      const incoming = Backup.parse(await file.text());
      const mode = $('backup-mode').value;
      const message = mode === 'replace' ? 'Replace all current devices and history with this backup? Export the current data first if needed.' : 'Merge this backup? Existing devices with matching IDs will be kept.';
      if (!confirm(`${message}\n\nBackup contains ${incoming.devices.length} devices and ${incoming.history.length} history entries.`)) return;
      const result = Backup.commit(localStorage, key, inventory, incoming, mode);
      inventory = new Inventory(result); render(); $('backup-message').textContent = 'Backup imported successfully.';
    } catch (error) { $('backup-message').textContent = `Import failed; current data was not changed: ${error.message}`; }
  });
  $('scan-refresh').addEventListener('click', async () => {
    try {
      const response = await fetch('/api/interfaces'); if (!response.ok) throw new Error();
      const data = await response.json(); const select = $('scan-subnet');
      select.replaceChildren(new Option('Select a subnet', ''));
      data.subnets.forEach(subnet => select.add(new Option(subnet, subnet)));
      $('scan-message').textContent = data.subnets.length ? 'Choose an authorized subnet to scan.' : 'No supported private IPv4 subnets found.';
    } catch (_) { $('scan-message').textContent = 'Local helper unavailable. Start helper.py and open its loopback URL.'; }
  });
  $('scan-button').addEventListener('click', async () => {
    if (!storageReady) { $('scan-message').textContent = 'Saved data could not be read; scanning is disabled.'; return; }
    const subnet = $('scan-subnet').value;
    if (!subnet) { $('scan-message').textContent = 'Select a local subnet first.'; return; }
    if (!confirm(`Scan ${subnet}? Only proceed if you own or are authorized to scan this network.`)) return;
    $('scan-button').disabled = true; $('scan-message').textContent = 'Scanning; results may be incomplete…';
    try {
      const response = await fetch('/api/scan', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Homewatch': '1' }, body: JSON.stringify({ subnet }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || 'Scan failed');
      if (!Array.isArray(result.devices) || result.devices.some(d => !d || !/^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$/i.test(d.mac) || !/^(?:\d{1,3}\.){3}\d{1,3}$/.test(d.ip))) throw new Error('Invalid scan response');
      inventory.applyScan(result.devices); const saved = save(); render();
      $('scan-message').textContent = `${result.devices.length} device(s) observed. Missing devices are not necessarily offline.${saved ? '' : ' Changes were not saved.'}`;
    } catch (error) { $('scan-message').textContent = `Scan failed: ${error.message}`; }
    finally { $('scan-button').disabled = false; }
  });
  render();
})();
