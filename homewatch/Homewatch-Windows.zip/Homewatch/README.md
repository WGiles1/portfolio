# Homewatch

A local-first notebook with optional user-initiated discovery. **This is not a security product**, continuous monitor, or vulnerability scanner. Only scan networks you own or have permission to scan.

## Run

On Windows, install Python 3.8 or newer from python.org (no third-party packages). This ZIP is not a self-contained installer and does not include Python. Extract the entire ZIP to a folder, then double-click **Start Homewatch.bat**. Open http://127.0.0.1:8765/ in your browser and keep the command window open. If the launcher cannot find Python, install Python and enable its launcher or add Python to PATH. If port 8765 is occupied, stop the other service and retry; never enter sensitive data into an unexpected page.

To discover devices, click **Find local subnets**, select an authorized subnet, click **Scan selected subnet**, and confirm. Stop Homewatch by pressing Ctrl+C in the command window or closing it. Manual use still works by opening `index.html` directly; scanning requires the helper.

The helper listens only on 127.0.0.1 and checks the browser's Host and Origin, but it is not authenticated against other software or other users on the same computer. Run it only on a trusted computer, do not expose or proxy its port, and close it when finished. Local malicious software or a compromised same-origin page can access the helper and browser data.

Storage is per browser origin. Existing data at `file:` or port 8000 does not automatically appear at port 8765: export a backup at the old origin and import it at the new one. Verify the import before removing old data.

Add, edit, search, and delete devices; change the flag in the edit form. Activity retains manual add/edit/delete records including old and new values. Entries and history are stored in the browser's localStorage for this origin. They are not encrypted or shared between browsers or origins. Clearing browser data or using private browsing can erase them. `file:` storage behavior varies by browser; use the loopback server if storage is blocked. If storage cannot be read, editing and backup are disabled to avoid overwriting existing data. If a write fails, the app warns you; changes may be lost on closing.

## Backup and restore

Use **Export backup** to download a JSON file containing all devices and history. The file is unencrypted and can contain sensitive addresses and notes; store it securely. To restore, select a mode and choose a backup, review the counts, then confirm. **Replace** overwrites the current inventory and history; export your current data first. **Merge** preserves existing devices on matching IDs, adds new IDs, and combines history by timestamp and text (keeping the larger number of identical entries). Different devices with different IDs are not deduplicated, even if their addresses match. The import accepts only Homewatch version 1 backup JSON, validates records and duplicate IDs, and limits files to 10 MB. Invalid files, cancellation, or storage write failure leave the current inventory unchanged. The import writes only after confirmation. This is not an automatic or encrypted backup.

## Discovery limitation

The loopback-only helper validates Host and Origin, lists Windows private IPv4 subnets and rechecks the chosen subnet at scan time. It limits each scan to a /24 or smaller, uses bounded concurrent ICMP pings and the local ARP cache, and does not scan ports. Only a deliberate confirmed request starts a scan; there is no background scan. Larger networks are limited to the /24 containing the interface. Virtual adapters and VPNs may appear; select carefully.

Scans can miss sleeping, offline, firewalled, isolated, IPv6-only, or non-responding devices. Only responding hosts with a usable ARP MAC are reported; absence does not mean offline, and last-seen is not current online status. Results may be incomplete or stale. New MACs are flagged unfamiliar for review; recurring MACs retain their flag and IP changes are recorded. MAC randomization can cause duplicates; MACs do not prove identity. Manual entries are not automatically merged with discovered records. Discovery does not remove devices or infer departures.

