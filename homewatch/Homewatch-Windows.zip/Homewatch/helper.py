"""Loopback-only Homewatch server. Discovery occurs only on an explicit POST."""
import concurrent.futures
import ipaddress
import json
import re
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = {'/': ('index.html', 'text/html'), '/index.html': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'), '/inventory.js': ('inventory.js', 'text/javascript'), '/backup.js': ('backup.js', 'text/javascript'), '/styles.css': ('styles.css', 'text/css')}
PRIVATE = [ipaddress.ip_network(s) for s in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')]

def interfaces():
    # PowerShell's built-in networking cmdlets return the address and prefix together.
    script = "Get-NetIPAddress -AddressFamily IPv4 | Select-Object IPAddress,PrefixLength | ConvertTo-Json -Compress"
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script], capture_output=True, text=True, timeout=15, check=True)
    entries = json.loads(result.stdout or '[]')
    if isinstance(entries, dict): entries = [entries]
    networks = set()
    for entry in entries:
        try:
            addr = ipaddress.IPv4Address(entry['IPAddress'])
            prefix = int(entry['PrefixLength'])
            if not 0 <= prefix <= 32 or not any(addr in p for p in PRIVATE): continue
            net = ipaddress.ip_network(f'{addr}/{max(prefix, 24)}', strict=False)
            if any(net.subnet_of(p) for p in PRIVATE): networks.add(str(net))
        except (ValueError, KeyError, TypeError): continue
    return sorted(networks)

def scan(net):
    def ping(ip):
        try:
            return subprocess.run(['ping', '-n', '1', '-w', '500', str(ip)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2).returncode == 0
        except (OSError, subprocess.TimeoutExpired): return False
    with concurrent.futures.ThreadPoolExecutor(max_workers=24) as pool:
        hosts = list(net.hosts())
        alive = {str(ip) for ip, ok in zip(hosts, pool.map(ping, hosts)) if ok}
    output = subprocess.run(['arp', '-a'], capture_output=True, text=True, timeout=10, check=True).stdout
    found = {}
    for ip, mac in re.findall(r'\b(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-fA-F]{2}(?:[-:][0-9a-fA-F]{2}){5})\b', output):
        if ip in alive:
            mac = mac.replace('-', ':').lower()
            if mac != 'ff:ff:ff:ff:ff:ff' and not (int(mac[:2], 16) & 1): found[ip] = mac
    return [{'ip': ip, 'mac': mac} for ip, mac in sorted(found.items(), key=lambda x: ipaddress.ip_address(x[0]))]

def make_server(port=8765, interfaces=interfaces, scanner=scan):
    lock = threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args): pass
        def send_data(self, status, body, mime='application/json'):
            self.send_response(status); self.send_header('Content-Type', mime + '; charset=utf-8'); self.send_header('Content-Length', str(len(body))); self.send_header('Cache-Control', 'no-store'); self.send_header('X-Content-Type-Options', 'nosniff'); self.end_headers(); self.wfile.write(body)
        def reply(self, status, value): self.send_data(status, json.dumps(value).encode())
        def allowed(self, require_origin=False):
            host = f'127.0.0.1:{self.server.server_port}'
            origin = self.headers.get('Origin')
            return self.headers.get('Host') == host and (origin == 'http://' + host if require_origin else origin in (None, 'http://' + host)) and self.headers.get('Sec-Fetch-Site', 'same-origin') in ('same-origin', 'none')
        def do_GET(self):
            if not self.allowed(): return self.reply(403, {'error': 'Forbidden'})
            if self.path == '/api/interfaces':
                try: return self.reply(200, {'subnets': interfaces()})
                except Exception: return self.reply(500, {'error': 'Could not enumerate Windows network interfaces.'})
            if self.path not in FILES: return self.reply(404, {'error': 'Not found'})
            filename, mime = FILES[self.path]; self.send_data(200, (ROOT / filename).read_bytes(), mime)
        def do_POST(self):
            if not self.allowed(True) or self.headers.get('X-Homewatch') != '1' or self.headers.get_content_type() != 'application/json': return self.reply(403, {'error': 'Forbidden'})
            if self.path != '/api/scan': return self.reply(404, {'error': 'Not found'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 1 <= size <= 1024: raise ValueError()
                data = json.loads(self.rfile.read(size))
                if not isinstance(data, dict) or set(data) != {'subnet'} or not isinstance(data['subnet'], str): raise ValueError()
                net = ipaddress.IPv4Network(data['subnet'], strict=True)
                if net.prefixlen < 24 or not any(net.subnet_of(p) for p in PRIVATE) or str(net) not in interfaces(): raise ValueError()
            except (ValueError, TypeError, json.JSONDecodeError): return self.reply(400, {'error': 'Choose a listed local subnet (maximum 256 addresses).'})
            except Exception: return self.reply(500, {'error': 'Could not verify local interfaces.'})
            if not lock.acquire(blocking=False): return self.reply(409, {'error': 'A scan is already running.'})
            try: self.reply(200, {'devices': scanner(net)})
            except Exception: self.reply(500, {'error': 'Scan failed; no results were saved.'})
            finally: lock.release()
    return ThreadingHTTPServer(('127.0.0.1', port), Handler)

if __name__ == '__main__':
    server = make_server()
    print('Homewatch: http://127.0.0.1:8765/  (Ctrl+C to stop)', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
