@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
  if not errorlevel 1 goto use_py
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
if not errorlevel 1 goto use_python
echo Python 3.8 or newer is required. Install Python from python.org and try again.
pause
exit /b 1
:use_py
echo Open http://127.0.0.1:8765/ in your browser. Keep this window open.
py -3 helper.py
goto finished
:use_python
echo Open http://127.0.0.1:8765/ in your browser. Keep this window open.
python helper.py
:finished
echo Homewatch stopped. If it failed to start, check that port 8765 is free.
pause
