(() => {
  const $ = id => document.getElementById(id);
  let data;
  try {
    const raw = localStorage.getItem('homewatch.inventory.v1');
    data = raw ? JSON.parse(raw) : {devices: [], history: []};
    if (!data || !Array.isArray(data.devices) || !Array.isArray(data.history)) throw new Error();
  } catch (_) { $('storage-error').textContent = 'Saved data could not be read. Statistics are unavailable; your data has not been changed.'; return; }
  const el = (tag, content, cls) => { const node = document.createElement(tag); node.textContent = content; if (cls) node.className = cls; return node; };
  const format = time => Number.isFinite(Date.parse(time)) ? new Date(time).toLocaleString() : 'Not recorded';
  $('last-scan').textContent = `Last completed scan: ${format(data.lastScan)}`;
  function render() {
    const from = $('from').value, to = $('to').value;
    $('range-error').textContent = from && to && from > to ? 'The start date must not be after the end date.' : '';
    const chart = $('chart'); chart.replaceChildren();
    const s = Statistics.calculate(data, from, to);
    $('total').textContent = data.devices.length; $('known').textContent = s.known; $('unfamiliar').textContent = s.unfamiliar;
    if (!$('range-error').textContent) {
      if (!s.days.length) chart.append(el('p', 'No recorded discovery or IP-change events in this date range.', 'history-empty'));
      const max = Math.max(1, ...s.days.flatMap(d => [d.discovered, d.ipChanges]));
      s.days.forEach(day => {
        const row = el('div', '', 'chart-row'); row.append(el('strong', day.date));
        [['New devices', day.discovered, 'new'], ['IP changes', day.ipChanges, 'changed']].forEach(([label, count, cls]) => {
          const line = el('div', '', 'bar-line'); const bar = el('span', '', `bar ${cls}`); bar.style.width = `${count / max * 100}%`;
          line.append(el('span', label), bar, el('strong', String(count))); row.append(line);
        }); chart.append(row);
      });
    }
    const observed = $('observed'); observed.replaceChildren();
    if (!s.observed.length) observed.append(el('p', 'No devices have recorded observations yet.', 'history-empty'));
    s.observed.forEach(d => { const item = el('div', '', 'history-item'); const details = el('div', ''); details.append(el('strong', d.name), el('small', `${d.address || 'No address'} · ${format(d.lastSeen)}`)); item.append(el('span', '·', 'timeline-dot'), details); observed.append(item); });
  }
  $('from').addEventListener('change', render); $('to').addEventListener('change', render);
  $('clear').addEventListener('click', () => { $('from').value = ''; $('to').value = ''; render(); });
  render();
})();