(function (root) {
  class Inventory {
    constructor(data = {}) { this.devices = data.devices || []; this.history = data.history || []; this.lastScan = data.lastScan; }
    applyScan(results, time = new Date().toISOString()) {
      for (const result of results) {
        const mac = result.mac.toLowerCase();
        let device = this.devices.find(d => d.mac && d.mac.toLowerCase() === mac);
        if (!device) {
          device = { id: globalThis.crypto.randomUUID(), name: `Device ${mac}`, status: 'unfamiliar', type: '', address: result.ip, notes: '', mac, lastSeen: time };
          this.devices.push(device);
          this.history.unshift({ time, text: `Discovered unfamiliar device ${mac} at ${result.ip}`, kind: 'discovered' });
        } else {
          if (device.address !== result.ip) {
            this.history.unshift({ time, text: `${device.name} address: ${device.address || '—'} → ${result.ip}`, kind: 'ip-change' });
            device.address = result.ip;
          }
          device.lastSeen = time;
        }
      }
      this.lastScan = time;
    }
    remove(id) {
      const index = this.devices.findIndex(d => d.id === id);
      if (index < 0) throw new Error('Device not found.');
      const [device] = this.devices.splice(index, 1);
      this.history.unshift({ time: new Date().toISOString(), text: `Deleted ${device.name}` });
    }
    update(id, input) {
      const device = this.devices.find(d => d.id === id);
      if (!device) throw new Error('Device not found.');
      const next = { name: input.name.trim(), status: input.status, type: input.type || '', address: input.address || '', notes: input.notes || '' };
      if (!next.name) throw new Error('Device name is required.');
      if (!['known', 'unfamiliar'].includes(next.status)) throw new Error('Choose a valid flag.');
      const changes = Object.keys(next).filter(k => device[k] !== next[k]).map(k => `${k}: ${device[k] || '—'} → ${next[k] || '—'}`);
      if (changes.length) { this.history.unshift({ time: new Date().toISOString(), text: `Updated ${device.name}: ${changes.join(', ')}` }); Object.assign(device, next); }
      return device;
    }
    add(input) {
      const device = { id: globalThis.crypto.randomUUID(), name: input.name.trim(), status: input.status, type: input.type || '', address: input.address || '', notes: input.notes || '' };
      if (!device.name) throw new Error('Device name is required.');
      if (!['known', 'unfamiliar'].includes(device.status)) throw new Error('Choose a valid flag.');
      this.devices.push(device);
      this.history.unshift({ time: new Date().toISOString(), text: `Added ${device.name} as ${device.status}` });
      return device;
    }
  }
  if (typeof module !== 'undefined') module.exports = { Inventory };
  else root.Inventory = Inventory;
})(globalThis);
