(function (root) {
  function calculate(data, from = '', to = '') {
    const days = new Map();
    for (const event of data.history || []) {
      if (!['discovered', 'ip-change'].includes(event.kind) || !Number.isFinite(Date.parse(event.time))) continue;
      const date = new Date(event.time).toISOString().slice(0, 10);
      if ((from && date < from) || (to && date > to)) continue;
      if (!days.has(date)) days.set(date, {date, discovered: 0, ipChanges: 0});
      days.get(date)[event.kind === 'discovered' ? 'discovered' : 'ipChanges']++;
    }
    const devices = data.devices || [];
    return { known: devices.filter(d => d.status === 'known').length, unfamiliar: devices.filter(d => d.status === 'unfamiliar').length,
      days: [...days.values()].sort((a,b) => a.date.localeCompare(b.date)),
      observed: devices.filter(d => d.lastSeen && Number.isFinite(Date.parse(d.lastSeen))).sort((a,b) => Date.parse(b.lastSeen) - Date.parse(a.lastSeen)) };
  }
  if (typeof module !== 'undefined') module.exports = {calculate}; else root.Statistics = {calculate};
})(globalThis);
