(function (root) {
  const api = {
    exportJSON(data) { return JSON.stringify({ format: 'homewatch-backup', version: 1, devices: data.devices, history: data.history, lastScan: data.lastScan }, null, 2); },
    commit(storage, key, local, incoming, mode) {
      if (!['merge', 'replace'].includes(mode)) throw new Error('Invalid import mode.');
      const result = mode === 'merge' ? api.merge(local, incoming) : incoming;
      storage.setItem(key, JSON.stringify(result));
      return result;
    },
    merge(local, incoming) {
      const ids = new Set(local.devices.map(d => d.id));
      const devices = local.devices.concat(incoming.devices.filter(d => !ids.has(d.id)));
      const counts = new Map();
      const identity = h => JSON.stringify([h.time, h.text]);
      for (const h of local.history) { const k = identity(h); counts.set(k, (counts.get(k) || 0) + 1); }
      const history = local.history.slice();
      for (const h of incoming.history) { const k = identity(h); const n = counts.get(k) || 0; if (n) counts.set(k, n - 1); else history.push(h); }
      history.sort((a, b) => Date.parse(b.time) - Date.parse(a.time));
      const lastScan = [local.lastScan, incoming.lastScan].filter(Boolean).sort((a, b) => Date.parse(b) - Date.parse(a))[0];
      return lastScan ? { devices, history, lastScan } : { devices, history };
    },
    parse(json) {
      const data = JSON.parse(json);
      if (!data || data.format !== 'homewatch-backup' || data.version !== 1 || !Array.isArray(data.devices) || !Array.isArray(data.history)) throw new Error('Invalid or unsupported backup format.');
      const ids = new Set();
      for (const d of data.devices) {
        if (!d || typeof d.id !== 'string' || !d.id.trim() || ids.has(d.id) || typeof d.name !== 'string' || !d.name.trim() || !['known', 'unfamiliar'].includes(d.status) || ['type', 'address', 'notes'].some(k => typeof d[k] !== 'string')) throw new Error('Invalid device record or duplicate ID.');
        if ((d.mac !== undefined && (typeof d.mac !== 'string' || !/^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$/i.test(d.mac))) || (d.lastSeen !== undefined && (typeof d.lastSeen !== 'string' || !Number.isFinite(Date.parse(d.lastSeen))))) throw new Error('Invalid discovery metadata.');
        ids.add(d.id);
      }
      for (const h of data.history) if (!h || typeof h.text !== 'string' || typeof h.time !== 'string' || !Number.isFinite(Date.parse(h.time))) throw new Error('Invalid history record.');
      if (data.lastScan !== undefined && (typeof data.lastScan !== 'string' || !Number.isFinite(Date.parse(data.lastScan)))) throw new Error('Invalid last scan time.');
      return data.lastScan === undefined ? { devices: data.devices, history: data.history } : { devices: data.devices, history: data.history, lastScan: data.lastScan };
    }
  };
  if (typeof module !== 'undefined') module.exports = api; else root.Backup = api;
})(globalThis);
